


int main()
{	

    int ch = 0; 
    int selection = 0; 
    int scrolly = 0; 

    char line[PATH_MAX];
    char cmdi[250];
    char filetarget[250];
    char idata[1240][250];

    char currentselection[PATH_MAX];
    strncpy( currentselection, "", PATH_MAX );

    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;






  void loaddir()
  {
    n = 0 ; 
    filemax = 0; 
    dirp = opendir( "." );
    while  ((dp = readdir( dirp )) != NULL  &&  
            n < sizeof idata / sizeof idata[ 0 ]) {
            if ( strcmp( dp->d_name , "." ) != 0 )
            if ( strcmp( dp->d_name , ".." ) != 0 )
            if ( dp->d_name[0] !=  '.' )
            {
              strncpy( idata[ n++ ] , dp->d_name , 250 );
            }
    }
    filemax = n-1 ; 
    closedir( dirp );

    if ( n > 1 )
      qsort( idata, n , sizeof idata[0], compare_fun );
  }





    loaddir();

    FILE *fpout; 
    fpout = fopen( "index.html" , "wb+" );
    fclose( fpout );

    int posy=2;
    fpout = fopen( "index.html" , "wb+" );
    for( n = 0 ; n <= filemax ; n++)
    {
          //if ( strcmp( fextension( idata[ n ] )  , "html" ) == 0 )
          printf( "%s\n", idata[ n ] );
	  if  ( strstr( idata[n] , ".html" ) != 0 ) 
	  {
             // <a href="https://www.w3schools.com/html/">Visit our HTML tutorial</a>
	     fputs( "<a href=\"", fpout );
  	     fputs( idata[n], fpout );
	     fputs( "\">", fpout );
	     fputs( fbasename( idata[n]), fpout );
	     fputs( "</a>" , fpout );
  	     fputs( "\n", fpout );
	     fputs( "<br>" , fpout );
  	     fputs( "\n", fpout );
  	     fputs( "\n", fpout );
	  }
    }
    fclose( fpout );

  /*
  <a href="https://www.w3schools.com/html/">Visit our HTML tutorial</a>
  */

    return 0;
}





