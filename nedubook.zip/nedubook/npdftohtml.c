




//////// MAIN 
int main( int argc, char *argv[])
{ 

    printf( "NPDFTOHTML\n" ); 

    char cwd[PATH_MAX];
    char cmdi[PATH_MAX];
    char targetfile[PATH_MAX];
    char sourcefile[PATH_MAX];




    char tmpfile[PATH_MAX];
    strncpy( tmpfile, strtimestamp(), PATH_MAX );

    ////////////////////////////////////////////////////////
    if ( argc == 2)
     if ( fexist( argv[1] ) == 1 ) 
     if ( strcmp( fextension( argv[1] ) , "pdf" ) ==  0 ) 
     {
          strncpy( targetfile, filename_newext( argv[1], "html" ) , PATH_MAX );
          strncpy( sourcefile, argv[1] , PATH_MAX );

          printf( "Convert from %s to %s\n", argv[1] , targetfile );
	  nrunwith( " pdftohtml -noframes -i ", sourcefile );

       return 0;
    }



    return 0; 
} 




